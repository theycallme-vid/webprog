

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2B Layout</title>
</head>
<body>

    <header>
    <div class="H" style="grid-template-columns: 40% 8% 11% 11% 11% 9%; display:grid; align-items:center; gap:15x;">
        <span align="right"><img src="ubaya.png" width="50%"></span>
        <strong align="center"><a href="" style="font-size: 18px; text-decoration:none; color:black;">Pendaftaran</a></strong>
        <strong align="center"><a href="" style="font-size: 18px; text-decoration:none; color:black;">Program Studi</a></strong>
        <strong align="center"><a href="" style="font-size: 18px; text-decoration:none; color:black;">International Programs</a></strong>
        <strong align="center"><a href="" style="font-size: 18px; text-decoration:none; color:black;">Ubaya West Campus</a></strong> 
        <img src="flag.png">
    </div>
        <br><br>
    </header>

    <div style="text-align: center;">
        <img src="news.png" width="60%">
    </div>

        <br><br><br>

    <div style="text-align: center;">
        <iframe width="95%" height="850" src="https://www.youtube.com/embed/wZ1c9ZGIcH4?si=0QHGQy3uMNlah0pJ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
    </div>
    
    <br><br><br><br><br>
    <img src="1.jpg" width="100%" >

    <div style="text-align: center;"><img src="proud.png"></div>

    <div class="artikel" style="text-align: center;">
        <h1 style="text-align: center;""><strong>Berita dan Artikel</strong></h1>
        <img src="artikel.png" width="60%">
    </div>

    <br><br>
    <div class="penghargaan" style="text-align: center;">
        <h1 style="text-align: center;""><strong>Penghargaan</strong></h1>
        <img src="penghargaan.png" width="70%">
    </div>

    <br><br>
    <div class="course" style="text-align: center;">
        <h1 style="text-align: center;""><strong><i>Education</i> Partner</strong></h1>
        <img src="education.png" width="30%">
    </div>


    <br><br><br><br><br><br><br><br>

    <div style="display:grid; grid-template-columns: 75% 25%;">
        <div>
            <h2 style="text-align: left; font-size: 28px"><strong>Sambutan Rektor</strong></h2>
            <p style="font-size: 28px;">Universitas Surabaya (UBAYA) yang berdiri sejak 11 Maret 1968, telah mencapai fase lima puluh tahun (usia emas) pada tahun 2018. Sejak awal berdirinya sampai saat ini dan di masa yang akan datang, UBAYA tetap memiliki komitmen utuh untuk mengutamakan kualitas.</p>
            <button style="background-color: black; color:white; padding: 20px; font-size:20px"><strong>Baca Selengkapnya</strong></button>
        </div>
        <div style="text-align: right;">
            <img src="rektor.jpg" width="100%">
        </div>
    </div>

    <br><br><br>
    <div style="grid-template-columns: 15% 30% 5% 10% 5% 25%; display:grid; align-items:start">
            <div style="background-color: white;"></div>
            <div style="font-size: 20px;">
                <p align="left"><img src="ubaya1.png"></p>
                <p align="justify">Universitas Surabaya (UBAYA) adalah sebuah universitas swasta di Surabaya, Jawa Timur, Indonesia. UBAYA memiliki empat buah kampus, yakni Kampus Ubaya Ngagel, Kampus Ubaya Tenggilis, Ubaya West Campus, dan Outdoor Campus di Trawas.</p>
                <span><strong style="color: red;">Contact Us</strong><br> Jl.Ngagel Jaya Selatan No. 169. <br> Surabaya 60284</span>
            </div>
            <div style="background-color: white;"></div>
            <div align="left" style="font-size: 20px;">
                <p><strong style="color:brown;">About Us</strong></p>
                <p>Tentang UBAYA</p>
                <p>Sejarah UBAYA</p>
                <p>Sambutan Rektor</p>
                <p>Pimpinan Universitas</p>
                <p>Lokasi Kampus</p>
                <br>
                <p><Strong style="color: brown;">Careers & Recruitment</Strong></p>
                <p>Fasilitas & Layanan</p>
                <p>Ubaya Medical Center (UMC)</p>
                <p>Rumah Sakit UBAYA</p>
                <p>UBAYA Training Center (UTC)</p>
                <p>Hubungan Internasional</p>
                <p>Layanan Konseling</p>
                <p>Perpustakaan</p>
                <p>UBAYA Language Center (ULC)</p>
                <p>UBAYA Guest House</p>
                <p>UBAYA Global Academy</p>
                <p>Verifikasi Alumni & Legalisir</p>
                <br>
                <p><strong style="color: brown;">Calon Mahasiswa</strong></p>
                <p>UBAYA FUTUREMAKERS</p>
                <p>Pendaftaran</p>
                <p>Pendaftaran Pascasarjana</p>
                <p>Beasiswa</p>
                <p>E-Brosur</p>
                <p>Informasi Indeks</p>
                <p>MOB</p>
                <p>International Students</p>
                <br>
                <p><strong style="color: brown;">Mahasiswa</strong></p>
                <p>Kalender Akademik</p>
                <p>Pedoman Mahasiswa</p>
                <p>MyUbaya</p>
                <p>Email Gooaya</p>
                <p>E-Learning ULS</p>
                <p>Warta UBAYA</p>
                <p>MBKM UBAYA</p>
                <p>International Program</p>
            </div>
            <div style="background-color: white;"></div>
            <div align="left" style="font-size: 20px;">
                <p style="color:red; font-weight:bold;">Unit & Lembaga</p>

                <p style="color:orange;">Unit Penunjang Akademik</p>
                <p>Departemen PKMII</p>

                <p style="color:orange;">Unit Penunjang Non-Akademik</p>

                <p>Direktorat Penjaminan Mutu Dan Audit Internal</p>
                <p>Direktorat Pengembangan Kemahasiswaan</p>
                <p>Direktorat Administrasi Akademik</p>
                <p>Direktorat Sistem Informasi Manajemen</p>
                <p>Direktorat Keuangan</p>
                <p>Direktorat Sumber Daya Manusia</p>
                <p>Direktorat Kerjasama Kelembagaan</p>
                <p>Direktorat Marketing & Public Relations</p>
                <p>Direktorat Pusat Pengembangan Kurikulum Pembelajaran</p>
                <p>Direktorat Manajemen Aset & Pengadaan (MAP)</p>
                <p>Direktorat Layanan Umum</p>
                <p>Direktorat Pusat Bahasa</p>

                <p style="color:orange;">Lembaga Penelitian dan Pengabdian Kepada Masyarakat</p>

                <p>Pusat Studi Hak Asasi Manusia</p>
                <p>Pusat Studi Lingkungan</p>
                <p>Pusat Studi Energi Terbarukan (PSET)</p>
                <p>Pusat Pemberdayaan Komunitas Perkotaan</p>
                <p>Pusat Bisnis Dan Industri</p>
                <p>Pusat Informasi Obat Dan Layanan Kefarmasian</p>
                <p>Pusat Studi Inovasi Industri Dan Kewirausahaan (PSIIK)</p>
            </div>

    </div>

</body>
</html>